--2.1--
select max(salary), min(salary),avg(salary) from 
employees 
group by(job_id);
--2.2--
select g.last_name, count(e.employee_id)
from employees g, employees e
where g.employee_id = e.manager_id
group by(g.last_name);

--2.3--
select job_id, avg(salary)
from employees 
group by (job_id)
having avg(salary) > 5000;

--2.4--
select max(salary) - min(salary) from 
employees e 
join departments
using(department_id)
join locations l
using(location_id)
group by l.city
having count(employee_id) > 10;

--2.5--
select count(employee_id), c.country_name from 
employees e 
join departments
using(department_id)
join locations l
using(location_id)
join countries c
using (country_id)
group by c.country_name,l.city
having count(employee_id) < 20;

--2.6--
select e.first_name, e.salary 
from employees e
where e.manager_id in (select g.employee_id
from employees g where g.last_name like 'King');

--2.7--
select e.first_name, e.salary from
employees e
where salary > (select avg(salary) from
    employees g
    join departments
    using (department_id)
    join locations
    using (location_id)
    join countries c
    using (country_id)
    where country_id like '%UK%');

--2.8--

select e.*
from employees e
where department_id = (select department_id 
                        from employees 
                        where email like 'JRUSSEL' and e.email not like 'JRUSSEL' );
                        
--2.9--

select e.* 
from employees e
join employees g
on e.department_id = g.department_id
where g.email like 'JRUSSEL' and
e.email not like 'JRUSSEL';

--2.10--
select last_name,employee_id, job_id 
from employees 
where salary < (select salary 
                from employees 
                where job_id like 'MK_MAN');
                
--2.11--
select last_name,employee_id, job_id 
from employees 
where salary > (select salary 
                from employees 
                where job_id like 'MK_MAN');
                
--2.12--

                